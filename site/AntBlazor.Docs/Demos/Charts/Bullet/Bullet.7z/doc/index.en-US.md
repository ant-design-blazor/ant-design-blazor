﻿---
category: Charts
type: Charts
title: Bullet
cols: 1
cover:
---

## When To Use
