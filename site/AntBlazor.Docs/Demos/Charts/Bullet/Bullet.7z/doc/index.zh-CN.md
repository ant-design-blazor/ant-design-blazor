﻿---
category: Charts
type: 图表
title: Bullet
subtitle: 子弹图
cols: 1
cover:
---

## 何时使用
