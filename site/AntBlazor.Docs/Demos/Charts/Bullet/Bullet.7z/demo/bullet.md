﻿---
order: 0
title:
  zh-CN: 子弹图
  en-US: Bullet
---

## zh-CN

## en-US

Description about this component.
